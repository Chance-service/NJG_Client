>./console.log
nohup java -jar -Dport=5134 execShell.jar >>./console.log &
tail -f console.log
